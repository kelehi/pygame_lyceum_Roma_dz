import pygame

def main():
    pygame.init()
    size = width, height = 600, 300
    player_x = -600
    screen = pygame.display.set_mode(size)
    game_over = pygame.image.load('gamer.jpg')
    running = True
    running_2 = True
    while running:
        if player_x >= 0:
            running_2 = False

        screen.fill((0, 0, 255))
        screen.blit(game_over, (player_x, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
        if running_2:
            player_x += 0.2
        pygame.display.update()


if __name__ == '__main__':
    main()

